"""
Configuration module for Desi-Reason AI.
Contains language definitions, system prompt templates, and pre-built scam & bargaining scenarios.
"""

# Supported Languages mapping as per specification
LANGUAGES = {
    "en": "English",
    "hi": "Hindi",
    "ta": "Tamil",
    "te": "Telugu",
    "bn": "Bengali",
    "mr": "Marathi",
    "gu": "Gujarati",
    "kn": "Kannada",
    "ml": "Malayalam",
    "pa": "Punjabi"
}

# Native language titles & UI translations
UI_STRINGS = {
    "en": {
        "title": "Desi-Reason AI",
        "subtitle": "Localized AI for Fraud Detection & Bargaining Assistance",
        "analyze_btn": "🔍 Analyze",
        "bargain_btn": "🤝 Help Me Bargain",
        "analysis_header": "Analysis Summary",
        "answer_header": "Recommended Action / Response",
        "fraud_mode": "Fraud Detection",
        "bargain_mode": "Bargaining Assistance",
        "input_placeholder": "Paste suspicious message, SMS, call transcript, or bargaining scenario here..."
    },
    "hi": {
        "title": "Desi-Reason AI (देशी रीज़न एआई)",
        "subtitle": "धोखाधड़ी पहचान और मोलभाव सहायता के लिए स्थानीय एआई",
        "analyze_btn": "🔍 विश्लेषण करें (Analyze)",
        "bargain_btn": "🤝 मोलभाव में मदद लें (Help Me Bargain)",
        "analysis_header": "विश्लेषण सारांश (Analysis Summary)",
        "answer_header": "अनुशंसित कार्रवाई / प्रतिक्रिया (Recommendation)",
        "fraud_mode": "धोखाधड़ी पहचान (Fraud Detection)",
        "bargain_mode": "मोलभाव सहायता (Bargaining Assistance)",
        "input_placeholder": "संदिग्ध संदेश, एसएमएस, कॉल विवरण या मोलभाव की स्थिति यहाँ दर्ज करें..."
    }
}

# Sample scenarios for quick testing in UI
SAMPLE_SCENARIOS = {
    "fraud": [
        {
            "label": "🏦 Bank KYC Scam",
            "text": "Dear Customer, your bank account will be blocked within 24 hours due to pending KYC. Click http://bank-kyc-verify-online.com to update immediately."
        },
        {
            "label": "💸 OLX UPI QR Scan Scam",
            "text": "The buyer on OLX agreed to buy my old laptop without bargaining. He sent a UPI QR code and said: 'Scan this QR code and enter your PIN to receive ₹15,000 advance payment.'"
        },
        {
            "label": "⚡ Electricity Disconnection Scam",
            "text": "Dear User, your power supply will be disconnected tonight at 9:30 PM due to previous month bill update failure. Immediately contact Electricity Officer at 9876543210."
        },
        {
            "label": "💼 YouTube Like Job Scam",
            "text": "Earn ₹3,000 to ₹8,000 daily working from home! Just like YouTube videos and send screenshots. Pay ₹500 initial registration fee to unlock task portal."
        }
    ],
    "bargain": [
        {
            "label": "🛺 Bangalore Auto Negotiate",
            "text": "The auto driver at Indiranagar station demands ₹300 for a 4 km trip to Koramangala. No meter. How can I negotiate a fair price?"
        },
        {
            "label": "🛍️ Delhi Cloth Market",
            "text": "The shopkeeper in Chandni Chowk quoted ₹3,500 for a lehenga/saree. What is a realistic starting counter-offer and negotiation strategy?"
        },
        {
            "label": "🏠 Apartment Rent Bargain",
            "text": "Landlord in Pune is asking ₹28,000 rent + 6 months deposit for a 2BHK flat. My budget is ₹23,000. How can I pitch my case effectively?"
        },
        {
            "label": "📱 Second-hand Phone",
            "text": "Seller on Facebook Marketplace is offering an iPhone 13 (1 year old) for ₹42,000. How do I spot flaws and bargain down to ₹35,000?"
        }
    ]
}
