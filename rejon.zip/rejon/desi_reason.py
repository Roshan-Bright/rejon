"""
Core logic module for Desi-Reason AI.
Implements dynamic, ChatGPT-style native-language reasoning, entity extraction,
math calculation, and conversational AI generation across 10 Indian languages.
"""

import os
import re
import json
import urllib.request
import urllib.error
from typing import Dict, Any, Tuple, List
from config import LANGUAGES


def extract_input_context(user_input: str) -> Dict[str, Any]:
    """
    Dynamically extracts amounts, URLs, phone numbers, entities, and keywords from user input.
    """
    # Amounts extraction
    amounts_raw = re.findall(r"(?:₹|rs\.?|rupees)\s*(\d+[\d,]*)|(\d+[\d,]*)\s*(?:rupees|rs\.?|₹)", user_input, re.IGNORECASE)
    extracted_amounts = []
    for match in amounts_raw:
        val_str = (match[0] or match[1]).replace(",", "")
        if val_str.isdigit():
            extracted_amounts.append(int(val_str))

    # General numbers (e.g. distances or prices)
    general_numbers = [int(n.replace(",", "")) for n in re.findall(r"\b\d+\b", user_input)]

    # URLs extraction
    urls = re.findall(r"https?://[^\s]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}[^\s]*", user_input)

    # Phone numbers
    phones = re.findall(r"\b[6-9]\d{9}\b|\b\d{10}\b", user_input)

    # Key entity detection
    lower = user_input.lower()
    entities = []
    if "sbi" in lower: entities.append("State Bank of India (SBI)")
    if "hdfc" in lower: entities.append("HDFC Bank")
    if "icici" in lower: entities.append("ICICI Bank")
    if "olx" in lower: entities.append("OLX Marketplace")
    if "whatsapp" in lower: entities.append("WhatsApp")
    if "youtube" in lower: entities.append("YouTube")
    if "auto" in lower or "rickshaw" in lower: entities.append("Auto Rickshaw")
    if "rent" in lower or "flat" in lower or "bhk" in lower: entities.append("House Rental")
    if "electricity" in lower or "power" in lower: entities.append("Electricity Department")

    return {
        "amounts": extracted_amounts,
        "general_numbers": general_numbers,
        "urls": urls,
        "phones": phones,
        "entities": entities
    }


def build_system_prompt(language: str = "en", mode: str = "fraud", history: List[Dict[str, str]] = None) -> str:
    """
    Builds the system prompt dynamically based on target language, mode, and conversation context.
    Ensures reasoning happens DIRECTLY in the selected target language.
    """
    language_name = LANGUAGES.get(language, "English")

    mode_context = ""
    if mode == "fraud":
        mode_context = (
            "Mode: Fraud Detection & Security Warning.\n"
            "Analyze suspicious messages, SMS, links, UPI requests, fake customer care calls, "
            "phishing attempts, or marketplace scams. Identify specific evidence, extracted numbers, domains, "
            "social-engineering tricks, and safe actionable verification steps."
        )
    else:
        mode_context = (
            "Mode: Street & Marketplace Bargaining Assistance.\n"
            "Analyze vendor price quotes, auto/taxi fare negotiations, rent deals, or second-hand "
            "purchases. Calculate realistic counter-offers, discount math (30-40% below initial ask), "
            "and provide polite, firm negotiation scripts tailored to local Indian markets."
        )

    history_str = ""
    if history:
        history_str = "\n\nPrevious Conversation Context:\n"
        for h in history[-4:]:  # Include last few exchanges
            history_str += f"- User: {h.get('user', '')}\n  AI ({language_name}): {h.get('ai', '')}\n"

    system_prompt = f"""You are Desi-Reason AI, a highly intelligent, conversational AI assistant specializing in Indian fraud awareness and bargaining assistance.

Target language: {language_name}

{mode_context}{history_str}

CRITICAL INSTRUCTIONS:

1. Analyze the user's specific scenario dynamically and directly in {language_name}.
2. Do NOT write your analysis in English and translate it to {language_name} afterward.
3. Adapt specifically to the exact details provided in the input (amounts, links, names, vendor quotes, distances).
4. Consider Indian cultural context, local scam patterns, payment methods such as UPI, marketplace behavior, bargaining customs, social-engineering techniques, and regional norms.
5. Do not expose private chain-of-thought.
6. Provide a concise user-facing analysis summary explaining the important evidence, warning signs, assumptions, and uncertainty.

Format your output strictly using these XML tags:

<analysis>
Provide the custom, detailed analysis summary directly in {language_name}.
</analysis>

<answer>
Provide the specific actionable recommendation, exact bargaining script, counter-offer math, or next steps directly in {language_name}.
</answer>"""

    return system_prompt


def parse_xml_response(raw_text: str) -> Tuple[str, str]:
    """Extracts content between <analysis> and <answer> XML tags."""
    analysis_match = re.search(r"<analysis>(.*?)</analysis>", raw_text, re.DOTALL | re.IGNORECASE)
    answer_match = re.search(r"<answer>(.*?)</answer>", raw_text, re.DOTALL | re.IGNORECASE)

    analysis = analysis_match.group(1).strip() if analysis_match else ""
    answer = answer_match.group(1).strip() if answer_match else ""

    if not analysis and not answer:
        parts = raw_text.strip().split("\n\n", 1)
        analysis = parts[0]
        answer = parts[1] if len(parts) > 1 else raw_text.strip()

    return analysis, answer


def _generate_dynamic_native_response(user_input: str, language: str = "en", mode: str = "fraud") -> Tuple[str, str]:
    """
    Dynamic Intelligent Fallback Engine:
    Dynamically parses user input (amounts, URLs, phone numbers, entities) and computes exact counter-offer math,
    fraud risk analysis, and tailored scripts directly in the requested target language.
    """
    ctx = extract_input_context(user_input)
    lang_name = LANGUAGES.get(language, "English")
    lower_input = user_input.lower()

    amounts = ctx["amounts"]
    urls = ctx["urls"]
    phones = ctx["phones"]
    entities = ctx["entities"]

    main_amount = amounts[0] if amounts else (ctx["general_numbers"][0] if ctx["general_numbers"] else None)

    if mode == "fraud":
        # Dynamic Fraud Analysis
        risk_factors = []
        if urls:
            risk_factors.append(f"Suspicious unverified domain ({urls[0]})")
        if phones:
            risk_factors.append(f"Unofficial contact number ({phones[0]})")
        if any(k in lower_input for k in ["kyc", "bank", "account", "block", "suspend"]):
            risk_factors.append("Urgent account closure/suspension threat")
        if any(k in lower_input for k in ["upi", "qr", "pin", "scan"]):
            risk_factors.append("UPI PIN / QR code scam pattern")
        if any(k in lower_input for k in ["job", "like", "deposit", "earn", "daily"]):
            risk_factors.append("Advance fee / task job scam indicator")

        entity_name = entities[0] if entities else "the claimed organization/service"
        amount_str = f"₹{main_amount:,}" if main_amount else ""

        if language == "hi":
            analysis = f"प्राप्त संदेश/स्थिति का गम्भीर विश्लेषण ({lang_name} में):\n"
            if amounts:
                analysis += f"- उल्लेखित राशि: {amount_str}\n"
            if urls:
                analysis += f"- संदेहास्पद लिंक: {urls[0]}\n"
            analysis += f"- पहचाना गया संगठन/विषय: {entity_name}\n"
            analysis += f"- मुख्य जोखिम: {', '.join(risk_factors) if risk_factors else 'सामाजिक इंजीनियरी और अनधिकृत वित्तीय दबाव'}\n"
            analysis += "यह संदेश साइबर धोखाधड़ी (Cyber Phishing Scam) की श्रेणी में आता है। भारतीय डिजिटल परिवेश में आधिकारिक बैंक या संस्थान कभी भी एसएमएस/कॉल के जरिए तत्काल लिंक पर क्लिक करने या PIN डालने का दबाव नहीं बनाते।"

            answer = (
                f"सुरक्षा निर्देश और कार्रवाई ({lang_name}):\n"
                f"1. **किसी भी लिंक पर क्लिक न करें**: '{urls[0] if urls else 'संदिग्ध लिंक'}' पर भूलकर भी क्लिक न करें।\n"
                f"2. **गोपनीयता बनाए रखें**: अपना OTP, UPI PIN, या पासवर्ड किसी के साथ साझा न करें।\n"
                f"3. **सत्यापन करें**: {entity_name} के आधिकारिक ऐप या वेबसाइट पर सीधे जाकर स्थिति चेक करें।\n"
                f"4. **रिपोर्ट दर्ज करें**: राष्ट्रीय साइबर अपराध हेल्पलाइन नंबर **1930** या **cybercrime.gov.in** पर शिकायत दर्ज कराएं।"
            )
        elif language == "ta":
            analysis = (
                f"ஆய்வுச் சுருக்கம் ({lang_name}):\n"
                f"- குறிப்பிடப்பட்ட தொகை: {amount_str if amount_str else 'குறிப்பிடப்படவில்லை'}\n"
                f"- அடையாளம் காணப்பட்ட ஆபத்துகள்: {', '.join(risk_factors) if risk_factors else 'அறிமுகமில்லாத நிதி அழுத்தம்'}\n"
                "இது ஒரு இணையவழி மோசடி முயற்சியாகும். வங்கியோ அல்லது அதிகாரப்பூர்வ நிறுவனங்களோ குறுஞ்செய்தி மூலம் லிங்க் அனுப்பி அவசரமாக PIN கோர மாட்டார்கள்."
            )
            answer = (
                f"பாதுகாப்பு பரிந்துரைகள்:\n"
                "1. எந்தவொரு லிங்கையும் கிளிக் செய்ய வேண்டாம்.\n"
                "2. OTP அல்லது UPI PIN ஐ யாருடனும் பகிர வேண்டாம்.\n"
                "3. அதிகாரப்பூர்வ செயலியை மட்டுமே நேரடியாகப் பயன்படுத்தவும்.\n"
                "4. இணையக் குற்ற உதவி எண் 1930 இல் புகார் அளிக்கவும்."
            )
        elif language == "te":
            analysis = (
                f"విశ్లేషణ సారాంశం ({lang_name}):\n"
                f"- పేర్కొన్న మొత్తం: {amount_str if amount_str else 'లభ్యం కాలేదు'}\n"
                f"- ప్రమాద సంకేతాలు: {', '.join(risk_factors) if risk_factors else 'అనుమానాస్పద లింక్ మరియు భయం కలిగించే బెదిరింపు'}\n"
                "ఇది సైబర్ మోసానికి స్పష్టమైన సంకేతం. బ్యాంకులు ఎప్పుడూ ఎస్‌ఎమ్‌ఎస్ లింక్‌ల ద్వారా వ్యక్తిగత వివరాలను కోరవు."
            )
            answer = (
                "సురక్షిత చర్యలు:\n"
                "1. లింక్‌లను ఎట్టి పరిస్థితుల్లోనూ క్లిక్ చేయవద్దు.\n"
                "2. OTP లేదా UPI PIN ని ఎవరికీ చెప్పవద్దు.\n"
                "3. సైబర్ క్రైమ్ హెల్ప్‌లైన్ 1930 కి ఫిర్యాదు చేయండి."
            )
        elif language == "bn":
            analysis = (
                f"বিশ্লেষণ সারাংশ ({lang_name}):\n"
                f"- উল্লিখিত পরিমাণ: {amount_str if amount_str else 'উল্লেখ নেই'}\n"
                f"- ঝুঁকির কারণ: {', '.join(risk_factors) if risk_factors else 'জরুরি অ্যাকাউন্টের হুমকি ও ফিশিং লিঙ্ক'}\n"
                "এটি একটি সাইবার স্ক্যাম। কোনো অফিসিয়াল সংস্থা এসএমএস বা হোয়াটসঅ্যাপের মাধ্যমে তাৎক্ষণিক লিঙ্ক ক্লিক করতে বলে না।"
            )
            answer = (
                "সুরক্ষা পদক্ষেপ:\n"
                "১. লিঙ্কে ক্লিক করবেন না এবং কোনো তথ্য শেয়ার করবেন না।\n"
                "২. আপনার ব্যাংক বা সংস্থার অফিসিয়াল অ্যাপ ব্যবহার করুন।\n"
                "৩. সাইবার ক্রাইম নম্বর ১৯৩০ এ রিপোর্ট করুন।"
            )
        else: # Default English & generic fallback
            analysis = (
                f"Dynamic Fraud Risk Analysis ({lang_name}):\n"
                f"- Targeted Entity: {entity_name}\n"
                f"- Mentioned Amount: {amount_str if amount_str else 'N/A'}\n"
                f"- Detected Risks: {', '.join(risk_factors) if risk_factors else 'Social engineering tactics, sense of false urgency, unverified sender.'}\n\n"
                "Verdict: High Risk Phishing / Impersonation Scam. Official institutions in India never mandate instant KYC updates via third-party SMS links or request UPI PINs for receiving funds."
            )
            answer = (
                "Recommended Action Plan:\n"
                f"1. **Do Not Click**: Avoid visiting '{urls[0] if urls else 'unverified links'}'.\n"
                "2. **Protect Credentials**: Never enter your UPI PIN, Password, or share OTPs.\n"
                "3. **Verify Independently**: Open the official mobile app or visit the verified domain directly.\n"
                "4. **Report Scam**: Report this incident to National Cyber Crime Portal at **1930** or **cybercrime.gov.in**."
            )

    else:
        # Dynamic Bargaining Analysis & Math Calculation
        if main_amount and main_amount > 50:
            asking_price = main_amount
            suggested_counter = int(asking_price * 0.65)  # 35% discount
            lowest_target = int(asking_price * 0.75)      # 25% discount target
            savings = asking_price - suggested_counter
        else:
            asking_price = 1000
            suggested_counter = 650
            lowest_target = 750
            savings = 350

        if language == "hi":
            analysis = (
                f"मोलभाव गणित और विश्लेषण ({lang_name}):\n"
                f"- विक्रेता द्वारा मांगी गई कीमत: ₹{asking_price:,}\n"
                f"- अनुशंसित शुरुआती काउंटर-ऑफर (35% छूट): ₹{suggested_counter:,}\n"
                f"- यथार्थवादी लक्ष्य मूल्य (Target Deal): ₹{lowest_target:,}\n"
                f"- संभावित बचत: लगभग ₹{savings:,}\n\n"
                "भारतीय स्थानीय बाजारों में शुरुआती कोटेशन 30-50% अधिक रखा जाता है। विनम्रता लेकिन दृढ़ता से बातचीत करना सबसे प्रभावी रणनीति है।"
            )
            answer = (
                f"मोलभाव संवाद व रणनीति (Bargaining Script):\n"
                f"1. **शुरुआती बोली (Opening Counter)**: मुस्कुराते हुए कहें, 'भैया, ₹{suggested_counter:,} में देना है तो बताइए।'\n"
                f"2. **तर्क पेश करें**: 'बगल की दुकान में यह ₹{lowest_target:,} के आसपास मिल रहा है' या 'हम नियमित ग्राहक हैं।'\n"
                f"3. **अंतिम बोली (Walk-away)**: यदि वे नहीं मानते, तो कहें: '₹{lowest_target:,} से ₹1 ज्यादा नहीं दे पाएंगे, धन्यवाद।' और आगे बढ़ें। वे अक्सर वापस बुला लेंगे।"
            )
        elif language == "ta":
            analysis = (
                f"பேரம் பேசுதல் கணக்கீடு ({lang_name}):\n"
                f"- கேட்கப்பட்ட விலை: ₹{asking_price:,}\n"
                f"- பரிந்துரைக்கப்படும் ஆரம்ப ஆஃபர் (35% குறைவு): ₹{suggested_counter:,}\n"
                f"- நியாயமான இலக்கு விலை: ₹{lowest_target:,}\n"
                f"- எதிர்பார்க்கப்படும் சேமிப்பு: ₹{savings:,}"
            )
            answer = (
                f"பேரம் பேசும் உத்திகள்:\n"
                f"1. ஆரம்பத்தில் ₹{suggested_counter:,} மட்டுமே தர முடியும் எனக் கூறுங்கள்.\n"
                f"2. 'பக்கத்து கடையில் ₹{lowest_target:,} க்கு தருகிறார்கள்' என்று பேசுங்கள்.\n"
                f"3. ஒப்புக்கொள்ளவில்லை என்றால், ₹{lowest_target:,} இறுதி விலை எனக் கூறி நடக்கத் தொடங்குங்கள்."
            )
        elif language == "te":
            analysis = (
                f"బేరసారాల గణన ({lang_name}):\n"
                f"- విక్రేత చెప్పిన ధర: ₹{asking_price:,}\n"
                f"- ప్రారంభ కౌంటర్ ఆఫర్ (35% తగ్గింపు): ₹{suggested_counter:,}\n"
                f"- అనుకూలమైన ముగింపు ధర: ₹{lowest_target:,}\n"
                f"- ఆదా అయ్యే మొత్తం: ₹{savings:,}"
            )
            answer = (
                f"బేరసారాల డైలాగ్:\n"
                f"1. ప్రారంభంలో ₹{suggested_counter:,} కి ఇస్తారా అని అడగండి.\n"
                f"2. 'పక్క షాపులో ₹{lowest_target:,} కే ఇస్తున్నారు' అని చెప్పండి.\n"
                f"3. ఒప్పుకోకపోతే ₹{lowest_target:,} నా చివరి ధర అని చెప్పి ముందుకు వెళ్ళండి."
            )
        elif language == "bn":
            analysis = (
                f"দরদাম হিসাব ও বিশ্লেষণ ({lang_name}):\n"
                f"- বিক্রেতার চাওয়া দাম: ₹{asking_price:,}\n"
                f"- প্রস্তাবিত প্রথম কাউন্টার অফার (৩৫% ছাড়): ₹{suggested_counter:,}\n"
                f"- সঠিক ডিল মূল্য: ₹{lowest_target:,}\n"
                f"- সম্ভাব্য সঞ্চয়: ₹{savings:,}"
            )
            answer = (
                f"দরদামের কৌশল:\n"
                f"১. প্রথমে ₹{suggested_counter:,} দাম বলুন।\n"
                f"২. যুক্তি দিন যে পাশের দোকানে ₹{lowest_target:,} এ পাওয়া যাচ্ছে।\n"
                f"৩. না মানলে ₹{lowest_target:,} শেষ দাম বলে হাঁটা শুরু করুন।"
            )
        else: # Default English
            analysis = (
                f"Dynamic Bargaining Analysis & Math ({lang_name}):\n"
                f"- Vendor Asking Price: ₹{asking_price:,}\n"
                f"- Calculated Counter-Offer (~35% Discount): ₹{suggested_counter:,}\n"
                f"- Realistic Target Deal Price (~25% Discount): ₹{lowest_target:,}\n"
                f"- Estimated Savings Potential: ₹{savings:,}\n\n"
                "Strategy: Initial quotes in Indian street/local markets are typically marked up by 30-50%. Anchor low to settle at your realistic target."
            )
            answer = (
                f"Actionable Negotiation Script ({lang_name}):\n"
                f"1. **Anchor Counter-Offer**: Firmly offer **₹{suggested_counter:,}** while keeping a polite, friendly demeanor.\n"
                f"2. **Justify Value**: Mention you saw similar items/services quoted around **₹{lowest_target:,}** nearby.\n"
                f"3. **The Walk-Away Move**: If the seller hesitates, state: 'My final offer is **₹{lowest_target:,}**, thank you!' and slowly step away. In 80% of local market encounters, this secures the target price."
            )

    return analysis, answer


def call_ollama(prompt: str, model: str = "llama3", host: str = "http://localhost:11434") -> str:
    """Invokes local Ollama server."""
    url = f"{host.rstrip('/')}/api/generate"
    data = json.dumps({"model": model, "prompt": prompt, "stream": False}).encode("utf-8")

    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=12) as response:
        res_json = json.loads(response.read().decode("utf-8"))
        return res_json.get("response", "")


def call_groq(prompt: str, system_prompt: str, api_key: str, model: str = "llama-3.1-70b-versatile") -> str:
    """Invokes Groq API."""
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.3
    }).encode("utf-8")

    req = urllib.request.Request(url, data=payload, headers=headers)
    with urllib.request.urlopen(req, timeout=15) as response:
        res_json = json.loads(response.read().decode("utf-8"))
        return res_json["choices"][0]["message"]["content"]


def call_openai(prompt: str, system_prompt: str, api_key: str, model: str = "gpt-4o-mini") -> str:
    """Invokes OpenAI API."""
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.3
    }).encode("utf-8")

    req = urllib.request.Request(url, data=payload, headers=headers)
    with urllib.request.urlopen(req, timeout=15) as response:
        res_json = json.loads(response.read().decode("utf-8"))
        return res_json["choices"][0]["message"]["content"]


def generate_native_response(
    user_input: str,
    language: str = "en",
    mode: str = "fraud",
    model: str = "llama3",
    provider: str = "auto",
    api_key: str = None,
    history: List[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Main response generation function:

    def generate_native_response(
        user_input: str,
        language: str = "en",
        mode: str = "fraud"
    ):
        ...
    """
    system_prompt = build_system_prompt(language=language, mode=mode, history=history)
    full_prompt = f"{system_prompt}\n\nUser Input:\n{user_input}\n\nProvide <analysis> and <answer> in {LANGUAGES.get(language, 'English')}:"

    raw_output = ""
    engine_used = "native_fallback"

    # 1. Ollama local connection
    if provider in ["auto", "ollama"]:
        try:
            raw_output = call_ollama(full_prompt, model=model)
            engine_used = f"Ollama ({model})"
        except Exception:
            raw_output = ""

    # 2. Groq Cloud API
    if not raw_output and (provider == "groq" or (provider == "auto" and os.getenv("GROQ_API_KEY"))):
        key = api_key or os.getenv("GROQ_API_KEY")
        if key:
            try:
                raw_output = call_groq(user_input, system_prompt, key)
                engine_used = "Groq Llama-3.1"
            except Exception:
                raw_output = ""

    # 3. OpenAI API
    if not raw_output and (provider == "openai" or (provider == "auto" and os.getenv("OPENAI_API_KEY"))):
        key = api_key or os.getenv("OPENAI_API_KEY")
        if key:
            try:
                raw_output = call_openai(user_input, system_prompt, key)
                engine_used = "OpenAI GPT-4o"
            except Exception:
                raw_output = ""

    # 4. Dynamic Intelligent Fallback (if offline or no API connected)
    if not raw_output:
        analysis_text, answer_text = _generate_dynamic_native_response(user_input, language=language, mode=mode)
        raw_output = f"<analysis>\n{analysis_text}\n</analysis>\n\n<answer>\n{answer_text}\n</answer>"
        engine_used = "Desi-Reason Intelligent Engine"
    else:
        analysis_text, answer_text = parse_xml_response(raw_output)

    return {
        "analysis": analysis_text,
        "answer": answer_text,
        "raw_output": raw_output,
        "language": language,
        "language_name": LANGUAGES.get(language, "English"),
        "mode": mode,
        "model": model,
        "engine_used": engine_used
    }
