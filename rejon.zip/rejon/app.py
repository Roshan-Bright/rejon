"""
Desi-Reason AI - Streamlit Responsive Web Application
ChatGPT-Style Interactive Multilingual AI for Fraud Detection & Bargaining Assistance.
"""

import streamlit as st
import time
from config import LANGUAGES, SAMPLE_SCENARIOS
from desi_reason import generate_native_response, build_system_prompt

# Page configuration
st.set_page_config(
    page_title="Desi-Reason AI - Indian Fraud & Bargaining Assistant",
    page_icon="🇮🇳",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS styling for full responsive ChatGPT-like design
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Plus Jakarta Sans', sans-serif;
    }

    /* Main Container Padding */
    .main .block-container {
        padding-top: 1.5rem;
        padding-bottom: 3rem;
        max-width: 1200px;
    }

    /* Hero Banner Header */
    .hero-banner {
        background: linear-gradient(135deg, #FF6F00 0%, #E65100 50%, #BF360C 100%);
        color: white;
        padding: 2rem 1.5rem;
        border-radius: 16px;
        box-shadow: 0 10px 25px rgba(255, 111, 0, 0.2);
        margin-bottom: 1.5rem;
        text-align: center;
    }

    .hero-title {
        font-size: 2.5rem;
        font-weight: 800;
        letter-spacing: -0.5px;
        margin-bottom: 0.3rem;
        color: #FFFFFF;
    }

    .hero-subtitle {
        font-size: 1.1rem;
        font-weight: 500;
        opacity: 0.95;
        color: #FFE0B2;
    }

    /* Chat Message Styling */
    .chat-user-msg {
        background-color: #F1F5F9;
        border: 1px solid #E2E8F0;
        border-radius: 14px 14px 2px 14px;
        padding: 1rem 1.25rem;
        margin-bottom: 1rem;
        color: #0F172A;
        font-weight: 500;
        max-width: 85%;
        margin-left: auto;
    }

    .chat-ai-container {
        margin-bottom: 1.5rem;
    }

    .custom-card {
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 14px;
        padding: 1.25rem 1.5rem;
        box-shadow: 0 4px 12px rgba(0,0,0,0.03);
        margin-bottom: 1rem;
    }

    .analysis-card {
        border-left: 6px solid #2563EB;
        background: #F0F9FF;
    }

    .answer-card {
        border-left: 6px solid #059669;
        background: #ECFDF5;
    }

    .card-title {
        font-size: 1.15rem;
        font-weight: 700;
        margin-bottom: 0.6rem;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .analysis-title { color: #1E40AF; }
    .answer-title { color: #065F46; }

    /* Badge Tags */
    .lang-badge {
        display: inline-block;
        background-color: #FEF3C7;
        color: #92400E;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }

    .engine-badge {
        display: inline-block;
        background-color: #E0E7FF;
        color: #3730A3;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }

    /* Buttons */
    div.stButton > button {
        border-radius: 10px;
        font-weight: 600;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .hero-title { font-size: 1.8rem; }
        .hero-subtitle { font-size: 0.95rem; }
        .chat-user-msg { max-width: 95%; }
    }
</style>
""", unsafe_allow_html=True)


# --- SESSION STATE INITIALIZATION ---
if "chat_history" not in st.session_state:
    st.session_state["chat_history"] = []

if "user_input" not in st.session_state:
    st.session_state["user_input"] = ""

if "current_mode" not in st.session_state:
    st.session_state["current_mode"] = "fraud"

if "single_result" not in st.session_state:
    st.session_state["single_result"] = None


# --- SIDEBAR CONFIGURATION & GUIDE ---
st.sidebar.markdown("## 🇮🇳 Desi-Reason AI")
st.sidebar.markdown("*Multilingual Fraud & Bargaining AI*")
st.sidebar.divider()

st.sidebar.markdown("### 🌐 Language Configuration")

# Language selectbox as required by specification:
# index=0 ensures "en" (English) is selected by default
selected_language = st.sidebar.selectbox(
    "Language",
    options=list(LANGUAGES.keys()),
    format_func=lambda x: LANGUAGES[x],
    index=0
)

active_lang_name = LANGUAGES[selected_language]
st.sidebar.info(f"Target AI Language: **{active_lang_name}** (`{selected_language}`)")

st.sidebar.divider()

st.sidebar.markdown("### ⚙️ Engine & Model")

selected_provider = st.sidebar.selectbox(
    "Execution Provider",
    options=["auto", "groq", "ollama", "openai", "fallback"],
    format_func=lambda x: {
        "auto": "⚡ Auto Detect (Intelligent Engine / Cloud / Ollama)",
        "groq": "🚀 Groq Cloud API (Fastest ChatGPT alternative)",
        "ollama": "💻 Local Ollama (llama3)",
        "openai": "🤖 OpenAI GPT-4o API",
        "fallback": "🧠 Desi-Reason Intelligent Engine (Offline)"
    }[x],
    index=0
)

selected_model = "llama3"
api_key_input = ""

if selected_provider in ["groq", "openai"]:
    api_key_input = st.sidebar.text_input(
        f"Enter {selected_provider.upper()} API Key",
        type="password",
        help="Paste key for live ChatGPT-level LLM streaming. Otherwise uses Intelligent Engine."
    )

st.sidebar.divider()

# Comprehensive Responsive User Guide in Sidebar Expander
with st.sidebar.expander("📖 User Guide & How to Run", expanded=False):
    st.markdown("""
    **Welcome to Desi-Reason AI!**
    
    - **Default Language**: Starts in **English (`en`)**.
    - **Language Switching**: Select Hindi, Tamil, Telugu, Bengali, Marathi, etc. from the sidebar to analyze scenarios **directly** in that native language.
    - **Modes**:
      1. 🛡️ **Fraud Detection**: Analyzes bank phishing, UPI QR code scams, fake job offers, electricity bill threats.
      2. 🤝 **Bargaining Assistance**: Calculates discount math (30-40%), counter-offers, and scripts for street markets, auto fares, rent deals.
    - **ChatGPT Mode**: Use the **💬 ChatGPT Chatbot Interface** tab for ongoing conversational follow-ups.
    """)

with st.sidebar.expander("🔍 View Dynamic System Prompt", expanded=False):
    st.code(build_system_prompt(language=selected_language, mode=st.session_state["current_mode"]), language="yaml")

st.sidebar.caption("© 2026 Desi-Reason AI | Responsive Multilingual Platform")


# --- MAIN INTERFACE ---

# Hero Banner
st.markdown("""
<div class="hero-banner">
    <div class="hero-title">🇮🇳 Desi-Reason AI</div>
    <div class="hero-subtitle">Localized AI for Fraud Detection & Bargaining Assistance</div>
</div>
""", unsafe_allow_html=True)


# Mode Selector Buttons
col_m1, col_m2 = st.columns(2)

with col_m1:
    if st.button("🛡️ Fraud Detection Mode", use_container_width=True, type="primary" if st.session_state["current_mode"] == "fraud" else "secondary"):
        st.session_state["current_mode"] = "fraud"
        st.rerun()

with col_m2:
    if st.button("🤝 Bargaining Assistance Mode", use_container_width=True, type="primary" if st.session_state["current_mode"] == "bargain" else "secondary"):
        st.session_state["current_mode"] = "bargain"
        st.rerun()

current_mode = st.session_state["current_mode"]

st.write("")

# Navigation Tabs: Single Analyzer vs ChatGPT Interactive Chatbot
tab_single, tab_chat = st.tabs(["🔍 Scenario Analyzer", "💬 ChatGPT Interactive Chatbot"])

# ==========================================
# TAB 1: SCENARIO ANALYZER
# ==========================================
with tab_single:
    st.markdown(f"#### 💡 Quick Test Scenarios ({'Fraud Detection' if current_mode == 'fraud' else 'Bargaining Assistance'})")

    scenarios = SAMPLE_SCENARIOS.get(current_mode, [])
    cols = st.columns(len(scenarios))

    for idx, sc in enumerate(scenarios):
        with cols[idx]:
            if st.button(sc["label"], key=f"chip_single_{current_mode}_{idx}", use_container_width=True):
                st.session_state["user_input"] = sc["text"]
                st.rerun()

    user_text = st.text_area(
        label="Scenario Input",
        value=st.session_state["user_input"],
        height=130,
        placeholder=(
            "e.g., 'Dear customer, your bank account will be blocked within 24 hours. Click http://sbi-verify.com'"
            if current_mode == "fraud"
            else "e.g., 'Auto driver at Bangalore station demands ₹350 for 4 km distance. How can I negotiate?'"
        ),
        key="single_text_input"
    )
    st.session_state["user_input"] = user_text

    col_btn1, col_btn2, _ = st.columns([2, 1, 3])

    with col_btn1:
        trigger = st.button("🔍 Analyze" if current_mode == "fraud" else "🤝 Help Me Bargain", type="primary", use_container_width=True)

    with col_btn2:
        if st.button("🗑️ Clear", key="clear_single", use_container_width=True):
            st.session_state["user_input"] = ""
            st.session_state["single_result"] = None
            st.rerun()

    if trigger:
        if not user_text.strip():
            st.warning("⚠️ Please enter a scenario or select a sample scenario above.")
        else:
            with st.spinner(f"Analyzing situation directly in {active_lang_name} ({selected_language})..."):
                time.sleep(0.3)
                res = generate_native_response(
                    user_input=user_text,
                    language=selected_language,
                    mode=current_mode,
                    model=selected_model,
                    provider=selected_provider,
                    api_key=api_key_input if api_key_input else None
                )
                st.session_state["single_result"] = res

    # Display Single Analysis Result
    res = st.session_state.get("single_result")
    if res:
        st.divider()
        st.markdown(f"### 📋 Analysis Result <span class='lang-badge'>Target: {res['language_name']} ({res['language']})</span> <span class='engine-badge'>Engine: {res['engine_used']}</span>", unsafe_allow_html=True)

        st.markdown(f"""
        <div class="custom-card analysis-card">
            <div class="card-title analysis-title">🧐 Analysis Summary ({res['language_name']})</div>
            <div style="font-size: 1.05rem; line-height: 1.6; color: #1E293B; white-space: pre-wrap;">{res['analysis']}</div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown(f"""
        <div class="custom-card answer-card">
            <div class="card-title answer-title">💡 Actionable Recommendation / Response ({res['language_name']})</div>
            <div style="font-size: 1.05rem; line-height: 1.6; color: #064E3B; white-space: pre-wrap;">{res['answer']}</div>
        </div>
        """, unsafe_allow_html=True)

        with st.expander("🔍 View Raw Output (<analysis> & <answer> tags)", expanded=False):
            st.code(res["raw_output"], language="xml")


# ==========================================
# TAB 2: CHATGPT INTERACTIVE CHATBOT
# ==========================================
with tab_chat:
    st.markdown("### 💬 Conversational ChatGPT Assistant")
    st.caption("Ask questions, paste messages, or ask follow-up questions in real-time conversation.")

    # Display Conversation Stream
    chat_history = st.session_state.get("chat_history", [])

    if not chat_history:
        st.info("👋 Start a conversation! Type your question or scenario below (e.g., 'What if the shopkeeper refuses my ₹2000 counter offer?').")

    for idx, item in enumerate(chat_history):
        # User message bubble
        st.markdown(f"""
        <div class="chat-user-msg">
            <b>👤 You:</b> {item['user']}
        </div>
        """, unsafe_allow_html=True)

        # AI response card
        st.markdown(f"""
        <div class="chat-ai-container">
            <div class="custom-card analysis-card">
                <div class="card-title analysis-title">🧐 Analysis Summary ({item['language_name']})</div>
                <div style="font-size: 1.02rem; line-height: 1.6; color: #1E293B; white-space: pre-wrap;">{item['analysis']}</div>
            </div>
            <div class="custom-card answer-card">
                <div class="card-title answer-title">💡 Recommendation / Tactics ({item['language_name']})</div>
                <div style="font-size: 1.02rem; line-height: 1.6; color: #064E3B; white-space: pre-wrap;">{item['answer']}</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

    # Chat Input Box
    chat_prompt = st.chat_input(f"Type your message or follow-up query in any context (Target language: {active_lang_name})...")

    if chat_prompt:
        # Build history context
        history_ctx = [{"user": h["user"], "ai": h["answer"]} for h in chat_history]

        with st.spinner(f"Desi-Reason AI is thinking directly in {active_lang_name}..."):
            time.sleep(0.3)
            ai_res = generate_native_response(
                user_input=chat_prompt,
                language=selected_language,
                mode=current_mode,
                model=selected_model,
                provider=selected_provider,
                api_key=api_key_input if api_key_input else None,
                history=history_ctx
            )

            st.session_state["chat_history"].append({
                "user": chat_prompt,
                "analysis": ai_res["analysis"],
                "answer": ai_res["answer"],
                "language_name": ai_res["language_name"]
            })
            st.rerun()

    if chat_history:
        if st.button("🗑️ Clear Chat History"):
            st.session_state["chat_history"] = []
            st.rerun()
