import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const samples = [
  { icon: "🎓", title: "Scholarship eligibility", text: "என் வயது 20. குடும்ப வருமானம் ₹1.5 லட்சம். நான் scholarship-க்கு தகுதியானவனா?" },
  { icon: "🏥", title: "Healthcare guidance", text: "எனக்கு அருகில் உள்ள அரசு மருத்துவமனைக்கு செல்ல என்ன செய்ய வேண்டும்?" },
  { icon: "🚌", title: "Travel decision", text: "Chennai-லிருந்து Mahabalipuram ஒரு நாள் trip போக ₹2000 போதுமா?" }
];

const initialReasoning = [
  { n: "01", label: "Language understood", value: "Tamil · conversational", state: "done" },
  { n: "02", label: "Intent detected", value: "Scholarship eligibility", state: "done" },
  { n: "03", label: "Facts extracted", value: "Age 20 · Income ₹1.5L · Student", state: "done" },
  { n: "04", label: "Rules evaluated", value: "3 / 3 conditions satisfied", state: "done" },
  { n: "05", label: "Decision generated", value: "Eligible", state: "done" }
];

function Icon({ name, size = 18 }) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round", strokeLinejoin: "round" };
  const paths = {
    spark: <><path d="M12 2l1.7 6.3L20 10l-6.3 1.7L12 18l-1.7-6.3L4 10l6.3-1.7L12 2Z"/><path d="M19 16l.7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z"/></>,
    chat: <><path d="M20 11.5a7.5 7.5 0 0 1-8 7.5 9 9 0 0 1-4-.9L4 20l1.2-3.1A7.2 7.2 0 0 1 4.5 13 7.5 7.5 0 0 1 12 6a7.5 7.5 0 0 1 8 5.5Z"/></>,
    brain: <><path d="M9.5 4.5A3 3 0 0 0 6 7.2a3.2 3.2 0 0 0-2 5.6A3.2 3.2 0 0 0 6.5 18a3 3 0 0 0 5.5 1.5V5.5a3 3 0 0 0-2.5-1Z"/><path d="M14.5 4.5A3 3 0 0 1 18 7.2a3.2 3.2 0 0 1 2 5.6 3.2 3.2 0 0 1-2.5 5.2 3 3 0 0 1-5.5 1.5V5.5a3 3 0 0 1 2.5-1Z"/><path d="M7 10h2M15 10h2M7.5 15h2M14.5 15h2"/></>,
    book: <><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5v-16Z"/><path d="M4 18.5A2.5 2.5 0 0 1 6.5 16H20"/></>,
    settings: <><path d="M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-1.8 1.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5v.2h-2.6v-.2a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1-1.8-1.8.1-.1A1.7 1.7 0 0 0 8 15a1.7 1.7 0 0 0-1.5-1H6.3v-2.6h.2A1.7 1.7 0 0 0 8 10a1.7 1.7 0 0 0-.3-1.9l-.1-.1 1.8-1.8.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.5v-.2h2.6v.2a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1 1.8 1.8-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.5 1h.2V14h-.2a1.7 1.7 0 0 0-1.5 1Z"/></>,
    send: <><path d="m22 2-7 20-4-9-9-4 20-7Z"/><path d="M22 2 11 13"/></>,
    mic: <><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    arrow: <><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    globe: <><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></>,
    chevron: <path d="m7 10 5 5 5-5"/>,
    close: <><path d="M6 6l12 12M18 6 6 18"/></>
  };
  return <svg {...common}>{paths[name]}</svg>;
}

function App() {
  const [query, setQuery] = useState("");
  const [language, setLanguage] = useState("Tamil");
  const [active, setActive] = useState("agent");
  const [sent, setSent] = useState(false);
  const [showRules, setShowRules] = useState(true);
  const [history, setHistory] = useState([]);
  const [recording, setRecording] = useState(false);

  const answer = useMemo(() => {
    if (!query) return null;
    return {
      title: "தகுதியானவர்",
      english: "Eligible",
      explanation: "ஆம். உங்கள் வயது, குடும்ப வருமானம் மற்றும் மாணவர் நிலை ஆகியவை இந்த scholarship-க்கான தேவைகளை பூர்த்தி செய்கின்றன.",
      bullets: [
        "உங்கள் வயது 20 — தேவையான 18–25 வரம்புக்குள் உள்ளது.",
        "குடும்ப வருமானம் ₹1.5 லட்சம் — அதிகபட்ச ₹2.5 லட்சத்திற்குள் உள்ளது.",
        "நீங்கள் மாணவர் என்பதால் மாணவர் நிபந்தனை பூர்த்தி செய்யப்படுகிறது."
      ]
    };
  }, [query]);

  const ask = (text = query) => {
    if (!text.trim()) return;
    setQuery(text);
    setSent(true);
    setHistory(h => [{ text, time: "Just now" }, ...h].slice(0, 4));
  };

  const startVoice = () => {
    setRecording(v => !v);
    if (!recording) {
      setTimeout(() => {
        setQuery("என் வயது 20. குடும்ப வருமானம் ₹1.5 லட்சம். நான் scholarship-க்கு தகுதியானவனா?");
        setRecording(false);
      }, 1300);
    }
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Icon name="spark" size={20}/></div>
          <div><strong>NammaGuide</strong><span>Reasoning AI</span></div>
        </div>

        <div className="workspace-label">WORKSPACE</div>
        <nav>
          <button className={active === "agent" ? "nav-item active" : "nav-item"} onClick={() => setActive("agent")}><Icon name="chat"/> <span>Agent</span><b>⌘1</b></button>
          <button className={active === "reasoning" ? "nav-item active" : "nav-item"} onClick={() => setActive("reasoning")}><Icon name="brain"/> <span>Reasoning Trail</span></button>
          <button className={active === "knowledge" ? "nav-item active" : "nav-item"} onClick={() => setActive("knowledge")}><Icon name="book"/> <span>Knowledge Base</span></button>
        </nav>

        <div className="workspace-label second">SYSTEM</div>
        <button className="nav-item"><Icon name="settings"/> <span>Settings</span></button>

        <div className="side-bottom">
          <div className="status-card">
            <div className="status-dot"></div>
            <div><strong>Agent online</strong><span>MeTTa engine ready</span></div>
          </div>
          <div className="profile-mini">
            <div className="avatar">R</div>
            <div><strong>Roshan</strong><span>Builder mode</span></div>
            <Icon name="chevron" size={15}/>
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="crumb"><span>Workspace</span><i>/</i><strong>Local Reasoning Agent</strong></div>
          <div className="top-actions">
            <div className="live"><span></span> LIVE DEMO</div>
            <button className="icon-button"><Icon name="globe" size={17}/></button>
            <button className="language" onClick={() => setLanguage(language === "Tamil" ? "English" : "Tamil")}>{language}<Icon name="chevron" size={14}/></button>
          </div>
        </header>

        <section className="content">
          <div className="hero-row">
            <div>
              <div className="eyebrow"><span className="pulse"></span> OMEGA / METTA REASONING</div>
              <h1>Ask. Reason.<br/><em>Understand.</em></h1>
              <p className="hero-copy">An AI agent that doesn't just translate your language — it explains <strong>why</strong> it made a decision, in a way that makes sense to you.</p>
            </div>
            <div className="metric-card">
              <span>REASONING STATUS</span>
              <strong>5</strong>
              <p>steps evaluated</p>
              <div className="mini-bars"><i></i><i></i><i></i><i></i><i></i></div>
            </div>
          </div>

          <div className="dashboard-grid">
            <section className="chat-panel panel">
              <div className="panel-head">
                <div><span className="section-icon purple"><Icon name="spark" size={16}/></span><div><strong>Reasoning Agent</strong><small>Local-language decision assistant</small></div></div>
                <span className="model-pill">NammaGuide v1.0</span>
              </div>

              {!sent ? (
                <div className="empty-chat">
                  <div className="orb"><Icon name="spark" size={28}/></div>
                  <h2>What should we reason about?</h2>
                  <p>Ask a question in Tamil or English. The agent will show the decision <strong>and</strong> the reasoning behind it.</p>
                  <div className="sample-grid">
                    {samples.map((s) => <button className="sample" key={s.title} onClick={() => ask(s.text)}><span>{s.icon}</span><div><strong>{s.title}</strong><small>{s.text}</small></div><Icon name="arrow" size={15}/></button>)}
                  </div>
                </div>
              ) : (
                <div className="conversation">
                  <div className="user-bubble"><span className="avatar small">R</span><p>{query}</p></div>
                  <div className="agent-answer">
                    <div className="answer-label"><span className="agent-dot"><Icon name="spark" size={13}/></span> NammaGuide</div>
                    <div className="decision"><div className="decision-icon"><Icon name="check" size={23}/></div><div><span>DECISION</span><h2>{answer.title}</h2><small>{answer.english} · 98% rule match</small></div></div>
                    <p className="answer-text">{answer.explanation}</p>
                    <div className="reason-list">{answer.bullets.map((b, i) => <div className="reason" key={i}><span>{i+1}</span><p>{b}</p></div>)}</div>
                    <button className="why-button" onClick={() => setShowRules(!showRules)}><Icon name="brain" size={15}/> {showRules ? "Hide" : "Show"} reasoning trail <Icon name="arrow" size={14}/></button>
                  </div>
                </div>
              )}

              <div className="composer">
                <button className={recording ? "mic recording" : "mic"} onClick={startVoice}><Icon name="mic" size={19}/></button>
                <input value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => e.key === "Enter" && ask()} placeholder="Ask in Tamil or English…" />
                <div className="composer-hint">{language} · Enter ↵</div>
                <button className="send" onClick={() => ask()}><Icon name="send" size={17}/></button>
              </div>
            </section>

            <aside className="right-column">
              <section className="panel trail">
                <div className="panel-head compact"><div><span className="section-icon blue"><Icon name="brain" size={16}/></span><div><strong>Reasoning Trail</strong><small>Auditable decision path</small></div></div><span className="live-tag">LIVE</span></div>
                <div className="trail-list">
                  {initialReasoning.map((r, i) => <div className="trail-item" key={r.n}><div className="trail-number">{r.n}</div><div className="trail-line"></div><div className="trail-copy"><strong>{r.label}</strong><span>{sent || i < 2 ? r.value : "Waiting for input…"}</span></div><span className={sent || i < 2 ? "check-dot" : "wait-dot"}>{sent || i < 2 ? <Icon name="check" size={10}/> : "·"}</span></div>)}
                </div>
                <div className="audit-note"><span>✦</span><p>Only the <strong>decision rationale</strong> is exposed. Private chain-of-thought is never displayed.</p></div>
              </section>

              {showRules && <section className="panel rules">
                <div className="panel-head compact"><div><span className="section-icon orange"><Icon name="book" size={16}/></span><div><strong>Rule Inspector</strong><small>MeTTa knowledge layer</small></div></div><span className="count">03</span></div>
                <div className="rule-row"><span className="rule-ok">✓</span><code>age &lt; 25</code><b>TRUE</b></div>
                <div className="rule-row"><span className="rule-ok">✓</span><code>income &lt; ₹250000</code><b>TRUE</b></div>
                <div className="rule-row"><span className="rule-ok">✓</span><code>student = true</code><b>TRUE</b></div>
                <div className="rule-result"><span>→</span><strong>eligible = true</strong></div>
              </section>}

              <section className="panel stats-panel">
                <div className="stat"><span>DECISIONS</span><strong>128</strong><small>+12 today</small></div>
                <div className="stat"><span>LANGUAGES</span><strong>06</strong><small>expanding</small></div>
                <div className="stat"><span>AVG. EXPLANATION</span><strong>2.4s</strong><small>response time</small></div>
              </section>
            </aside>
          </div>

          {history.length > 0 && <section className="recent">
            <div className="recent-head"><span>RECENT QUESTIONS</span><button onClick={() => setHistory([])}>Clear</button></div>
            <div className="history-row">{history.map((h, i) => <button key={i} onClick={() => ask(h.text)}><Icon name="clock" size={14}/><span>{h.text}</span><small>{h.time}</small></button>)}</div>
          </section>}
        </section>

        <footer><span>© 2026 NammaGuide</span><span><i></i> Reasoning engine connected</span><span>Built for accessible AI</span></footer>
      </main>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
