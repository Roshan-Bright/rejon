# 🇮🇳 Desi-Reason AI

> **Localized AI for Fraud Detection & Bargaining Assistance across Indian Languages**

**Desi-Reason AI** is an intelligent, culturally-aware multilingual assistant engineered to analyze suspicious scam messages (bank phishing, UPI QR code frauds, fake job offers, electricity bill scams) and street/marketplace bargaining scenarios directly in 10 major Indian languages.

---

## 🌟 Key Features

1. **Default English (`en`) Configuration**:
   - Application defaults to **English** automatically upon startup.
   - Streamlit selectbox index defaults to `0` (`en`).
   - Function signature defaults strictly to `language="en"`.

2. **Native-Language Analysis (No Translation Step)**:
   - The AI reasons **directly** in the user's selected language.
   - Eliminates `English reasoning → translation` artifacts to ensure natural phrasing and cultural nuances.
   - Structured XML output parsing (`<analysis>` and `<answer>`).

3. **Indian Regional & Cultural Context**:
   - Deep awareness of local scam mechanics (UPI PIN rules, OLX scan scam, SBI KYC phishing, WhatsApp job scams).
   - Practical street bargaining strategies (Bangalore auto rates, Delhi market counter-offers, house rent negotiation).

4. **10 Supported Indian Languages**:
   ```python
   LANGUAGES = {
       "en": "English",
       "hi": "Hindi",
       "ta": "Tamil",
       "te": "Telugu",
       "bn": "Bengali",
       "mr": "Marathi",
       "gu": "Gujarati",
       "kn": "Kannada",
       "ml": "Malayalam",
       "pa": "Punjabi"
   }
   ```

5. **Multi-Engine LLM Support with Zero-Fail Native Fallback**:
   - **Ollama**: Local execution with `llama3`.
   - **Cloud LLM APIs**: Groq, OpenAI, Google Gemini.
   - **Desi-Reason Native Engine**: Works 100% offline out-of-the-box if no API key or local server is connected.

---

## 🚀 Quick Start

### 1. Installation

Clone or extract the repository, then install requirements:

```bash
pip install -r requirements.txt
```

### 2. Run the Streamlit Application

```bash
streamlit run app.py
```

Open your browser at `http://localhost:8501`.

---

## 🧪 Running Unit Tests

Run the test suite to verify language defaults, dynamic system prompts, XML parsing, and reasoning logic:

```bash
python -m unittest test_desi_reason.py
```

---

## 🛠 Project Architecture

```
rejon/
├── app.py                # Streamlit Web UI (Sidebar, quick chips, language selector, cards)
├── desi_reason.py        # Core logic, dynamic prompts, LLM connectors & XML parser
├── config.py             # Supported LANGUAGES dictionary, UI strings & sample scenarios
├── test_desi_reason.py   # Unit test suite (7 passing test cases)
├── requirements.txt      # Dependencies (Streamlit, requests, etc.)
├── .env.example          # Template for optional API keys
└── README.md             # Documentation
```

---

## 💻 Core API Usage

```python
from desi_reason import generate_native_response

# 1. Default (English, Fraud Detection)
result = generate_native_response("Dear SBI customer, your KYC is expired. Click http://sbi-verify.com")

print(result["analysis"])  # Extracted from <analysis> tag
print(result["answer"])    # Extracted from <answer> tag

# 2. Hindi Selection
result_hi = generate_native_response(
    user_input="बैंक खाता 24 घंटे में बंद हो जाएगा। तुरंत KYC पूरा करने के लिए लिंक पर क्लिक करें।",
    language="hi",
    mode="fraud"
)

# 3. Bargaining Assistance (Bangalore Auto)
result_bargain = generate_native_response(
    user_input="Auto driver asking ₹350 for 4km distance without meter.",
    language="en",
    mode="bargain"
)
```

---

## 📜 System Prompt Specification

The system prompt is dynamically assembled:

```text
You are Desi-Reason AI, a multilingual AI assistant specializing in Indian fraud awareness and bargaining assistance.

Target language: {language_name}

IMPORTANT:

Analyze the user's situation directly in {language_name}.

Do not first formulate your analysis in English and translate it into {language_name} afterward.

Your analysis summary and final response must naturally use {language_name}.

Consider Indian cultural context, local scam patterns, payment methods such as UPI, marketplace behavior, bargaining customs, social-engineering techniques, and regional norms where relevant.

Do not expose private chain-of-thought.

Instead provide a concise user-facing analysis summary explaining the important evidence, warning signs, assumptions, and uncertainty.
```
