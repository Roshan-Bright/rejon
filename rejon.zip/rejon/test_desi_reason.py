"""
Comprehensive unit test suite for Desi-Reason AI.
Tests default values, system prompt construction, tag parsing, native language output, and function signatures.
"""

import unittest
from config import LANGUAGES
from desi_reason import generate_native_response, build_system_prompt, parse_xml_response


class TestDesiReasonAI(unittest.TestCase):

    def test_languages_dictionary(self):
        """Verify the exact required 10 languages and codes are present."""
        expected = {
            "en": "English",
            "hi": "Hindi",
            "ta": "Tamil",
            "te": "Telugu",
            "bn": "Bengali",
            "mr": "Marathi",
            "gu": "Gujarati",
            "kn": "Kannada",
            "ml": "Malayalam",
            "pa": "Punjabi"
        }
        self.assertEqual(LANGUAGES, expected)

    def test_default_function_signature_and_defaults(self):
        """Verify default language parameter is 'en' and mode is 'fraud'."""
        import inspect
        sig = inspect.signature(generate_native_response)
        params = sig.parameters
        
        self.assertEqual(params['language'].default, 'en')
        self.assertEqual(params['mode'].default, 'fraud')

    def test_system_prompt_building(self):
        """Verify dynamic system prompt construction for English and Hindi."""
        prompt_en = build_system_prompt(language="en", mode="fraud")
        self.assertIn("Target language: English", prompt_en)
        self.assertIn("Analyze the user's situation directly in English.", prompt_en)
        self.assertIn("Do not first formulate your analysis in English and translate it", prompt_en)

        prompt_hi = build_system_prompt(language="hi", mode="fraud")
        self.assertIn("Target language: Hindi", prompt_hi)
        self.assertIn("Analyze the user's situation directly in Hindi.", prompt_hi)

    def test_xml_parsing(self):
        """Verify <analysis> and <answer> XML tag parsing."""
        sample_xml = (
            "<analysis>\nThis is suspicious banking message.\n</analysis>\n\n"
            "<answer>\nDo not click link.\n</answer>"
        )
        analysis, answer = parse_xml_response(sample_xml)
        self.assertEqual(analysis, "This is suspicious banking message.")
        self.assertEqual(answer, "Do not click link.")

    def test_native_response_english_default(self):
        """Test response generation with default parameters (language='en')."""
        result = generate_native_response("Dear SBI customer, your KYC is expired. Click http://sbi.verify-kyc.com")
        self.assertEqual(result["language"], "en")
        self.assertEqual(result["mode"], "fraud")
        self.assertTrue(len(result["analysis"]) > 0)
        self.assertTrue(len(result["answer"]) > 0)
        self.assertIn("<analysis>", result["raw_output"])
        self.assertIn("<answer>", result["raw_output"])

    def test_native_response_hindi(self):
        """Test response generation with Hindi language setting."""
        result = generate_native_response(
            "आपका बैंक खाता 24 घंटे में ब्लॉक हो जाएगा। तुरंत KYC पूरा करने के लिए लिंक पर क्लिक करें।",
            language="hi",
            mode="fraud"
        )
        self.assertEqual(result["language"], "hi")
        self.assertTrue(len(result["analysis"]) > 0)
        self.assertTrue(len(result["answer"]) > 0)

    def test_bargaining_mode(self):
        """Test bargaining mode for Bangalore Auto fare scenario in English."""
        result = generate_native_response(
            "Auto driver at Indiranagar station asking ₹300 for 4km distance.",
            language="en",
            mode="bargain"
        )
        self.assertEqual(result["mode"], "bargain")
        self.assertTrue(len(result["analysis"]) > 0)
        self.assertTrue(len(result["answer"]) > 0)

    def test_bargaining_mode_multilingual(self):
        """Test native bargaining responses across regional languages."""
        for lang_code in ["hi", "ta", "te", "bn", "mr", "gu", "kn", "ml", "pa"]:
            result = generate_native_response(
                "Market seller quoted ₹2,500 for a dress.",
                language=lang_code,
                mode="bargain"
            )
            self.assertEqual(result["language"], lang_code)
            self.assertEqual(result["mode"], "bargain")
            self.assertTrue(len(result["analysis"]) > 0)
            self.assertTrue(len(result["answer"]) > 0)


if __name__ == "__main__":
    unittest.main()
