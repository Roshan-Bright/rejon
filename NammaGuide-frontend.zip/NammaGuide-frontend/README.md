# NammaGuide AI — Advanced Frontend

A frontend-only prototype for the "local-language reasoning agent" hackathon challenge.

## What is included

- Advanced dark/purple AI dashboard
- Tamil + English language toggle
- Local-language question composer
- Sample prompts
- Simulated reasoning trail
- MeTTa rule inspector UI
- Decision/result card
- Voice-input demo button (simulated in frontend)
- Recent questions
- Responsive mobile layout

## Important

This version is **frontend-only**. The reasoning response is simulated locally so you can demonstrate the UI before connecting a real LLM, MeTTa/Hyperon service, database, or FastAPI backend.

## Run

Requirements:
- Node.js 18+ recommended
- VS Code

Commands:

```bash
npm install
npm run dev
```

Open the URL Vite prints, normally:

http://localhost:5173

## Production build

```bash
npm run build
npm run preview
```

## Next backend connection

Replace the `ask()` demo function in `src/main.jsx` with a `fetch()` call to your backend, for example:

```js
const response = await fetch("http://localhost:8000/ask", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    language: language === "Tamil" ? "ta" : "en",
    question: text
  })
});

const data = await response.json();
```

Expected backend response can be:

```json
{
  "decision": "Eligible",
  "title": "தகுதியானவர்",
  "explanation": "உங்கள் நிபந்தனைகள் அனைத்தும் பூர்த்தி செய்யப்படுகின்றன.",
  "reasons": [
    "வயது நிபந்தனை பூர்த்தி",
    "வருமான நிபந்தனை பூர்த்தி",
    "மாணவர் நிபந்தனை பூர்த்தி"
  ],
  "rules": [
    "age < 25",
    "income < 250000",
    "student = true"
  ]
}
```
